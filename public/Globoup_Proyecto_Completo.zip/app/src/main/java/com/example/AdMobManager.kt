package com.example

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

/**
 * Configuración centralizada de identificadores de Google AdMob.
 * Permite alternar fácilmente entre entorno de PRUEBAS (Test IDs oficiales de Google)
 * y entorno de PRODUCCIÓN (Tus IDs reales de tu consola de AdMob).
 */
object AdConfig {
    /**
     * Alternador de Entorno de AdMob:
     * - IS_TEST_MODE = true  -> Utiliza los IDs de prueba oficiales de Google (Google Sample Test IDs).
     *                           OBLIGATORIO durante el desarrollo y las pruebas cerradas para los 12 testers en Google Play.
     * - IS_TEST_MODE = false -> Utiliza los IDs reales de tu cuenta de AdMob al publicar a Producción general.
     */
    const val IS_TEST_MODE = true

    // =========================================================================
    // 1. IDENTIFICADORES DE PRUEBA OFICIALES DE GOOGLE (Test IDs)
    // =========================================================================
    private const val TEST_BANNER_AD_ID = "ca-app-pub-3940256099942544/6300978111"
    private const val TEST_INTERSTITIAL_AD_ID = "ca-app-pub-3940256099942544/1033173712"
    private const val TEST_REWARDED_AD_ID = "ca-app-pub-3940256099942544/5224354917"

    // =========================================================================
    // 2. IDENTIFICADORES DE PRODUCCIÓN DE TU CUENTA DE ADMOB (Production IDs)
    // =========================================================================
    // Sustituye estos valores con los IDs reales creados en https://admob.google.com
    private const val PROD_BANNER_AD_ID = "ca-app-pub-3940256099942544/6300978111"
    private const val PROD_INTERSTITIAL_AD_ID = "ca-app-pub-3940256099942544/1033173712"
    private const val PROD_REWARDED_AD_ID = "ca-app-pub-3940256099942544/5224354917"

    // Identificadores activos según el entorno
    val BANNER_AD_ID: String
        get() = if (IS_TEST_MODE) TEST_BANNER_AD_ID else PROD_BANNER_AD_ID

    val INTERSTITIAL_AD_ID: String
        get() = if (IS_TEST_MODE) TEST_INTERSTITIAL_AD_ID else PROD_INTERSTITIAL_AD_ID

    val REWARDED_AD_ID: String
        get() = if (IS_TEST_MODE) TEST_REWARDED_AD_ID else PROD_REWARDED_AD_ID

    // Cooldown mínimo de seguridad entre anuncios intersticiales (política anti-spam de AdMob)
    const val MIN_INTERSTITIAL_COOLDOWN_MS = 40_000L

    // Ciclo de partidas intercaladas solicitado: 3, 6, 9
    val AD_CYCLE_INTERVALS = listOf(3, 6, 9)
}

/**
 * Gestor integral de publicidad Google AdMob y modo híbrido Offline/Online.
 */
class AdMobManager private constructor(private val appContext: Context) {

    companion object {
        private const val TAG = "AdMobManager"
        @Volatile
        private var instance: AdMobManager? = null

        fun getInstance(context: Context): AdMobManager {
            return instance ?: synchronized(this) {
                instance ?: AdMobManager(context.applicationContext).also { instance = it }
            }
        }
    }

    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var isInterstitialLoading = false
    private var isRewardedLoading = false

    private var gamesSinceLastAd = 0
    private var cycleIndex = 0
    private var currentThreshold = AdConfig.AD_CYCLE_INTERVALS[0] // Empieza en 3
    private var lastInterstitialShowTime = 0L

    private val _isRewardedAdReady = MutableStateFlow(false)
    val isRewardedAdReady: StateFlow<Boolean> = _isRewardedAdReady.asStateFlow()

    private val _isOnline = MutableStateFlow(isNetworkAvailable())
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    init {
        initializeSdk()
    }

    /**
     * Inicializa Google Mobile Ads SDK de forma asíncrona y segura.
     */
    fun initializeSdk() {
        try {
            _isOnline.value = isNetworkAvailable()
            MobileAds.initialize(appContext) { status ->
                Log.d(TAG, "AdMob inicializado correctamente: $status")
                if (isNetworkAvailable()) {
                    loadInterstitialAd()
                    loadRewardedAd()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error inicializando MobileAds: ${e.message}")
        }
    }

    /**
     * Comprueba si el dispositivo tiene conexión a internet activa (datos o WiFi).
     */
    fun isNetworkAvailable(): Boolean {
        return try {
            val connectivityManager = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val network = connectivityManager?.activeNetwork ?: return false
            val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Carga preventiva del anuncio intersticial si hay internet.
     */
    fun loadInterstitialAd() {
        if (!isNetworkAvailable() || isInterstitialLoading || interstitialAd != null) return

        isInterstitialLoading = true
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            appContext,
            AdConfig.INTERSTITIAL_AD_ID,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    Log.d(TAG, "Anuncio intersticial cargado exitosamente")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                    Log.w(TAG, "Fallo al cargar intersticial: ${loadAdError.message}")
                }
            }
        )
    }

    /**
     * Carga preventiva del anuncio bonificado (Rewarded) para revivir con escudo.
     */
    fun loadRewardedAd() {
        if (!isNetworkAvailable() || isRewardedLoading || rewardedAd != null) return

        isRewardedLoading = true
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            appContext,
            AdConfig.REWARDED_AD_ID,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                    _isRewardedAdReady.value = true
                    Log.d(TAG, "Anuncio bonificado cargado exitosamente")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    rewardedAd = null
                    isRewardedLoading = false
                    _isRewardedAdReady.value = false
                    Log.w(TAG, "Fallo al cargar bonificado: ${loadAdError.message}")
                }
            }
        )
    }

    /**
     * Evalúa si corresponde mostrar un anuncio intersticial en Game Over
     * según el ciclo intercalado 3, 6, 9 y el cooldown de seguridad de AdMob.
     * Si no hay internet, continúa el juego sin interrupción.
     */
    fun onGameFinished(activity: Activity?, onAdClosed: () -> Unit) {
        gamesSinceLastAd++
        _isOnline.value = isNetworkAvailable()

        Log.d(TAG, "Partidas acumuladas: $gamesSinceLastAd / Objetivo actual: $currentThreshold")

        // Si estamos sin conexión o aún no llegamos al umbral, continuamos directo
        if (!isNetworkAvailable() || gamesSinceLastAd < currentThreshold) {
            onAdClosed()
            return
        }

        // Validación de Cooldown de seguridad (para no ser intrusivo y cumplir políticas)
        val now = System.currentTimeMillis()
        if (now - lastInterstitialShowTime < AdConfig.MIN_INTERSTITIAL_COOLDOWN_MS) {
            Log.d(TAG, "Cooldown activo. Continuando sin anuncio para no saturar al usuario.")
            onAdClosed()
            return
        }

        val ad = interstitialAd
        if (ad != null && activity != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Intersticial cerrado por el usuario.")
                    interstitialAd = null
                    advanceCycle()
                    loadInterstitialAd()
                    onAdClosed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    Log.w(TAG, "Error mostrando intersticial: ${adError.message}")
                    interstitialAd = null
                    advanceCycle()
                    loadInterstitialAd()
                    onAdClosed()
                }

                override fun onAdShowedFullScreenContent() {
                    lastInterstitialShowTime = System.currentTimeMillis()
                }
            }
            ad.show(activity)
        } else {
            // El anuncio no estaba listo o falló la carga preventiva; no bloqueamos al jugador
            advanceCycle()
            loadInterstitialAd()
            onAdClosed()
        }
    }

    /**
     * Avanza al siguiente umbral en el bucle intercalado [3, 6, 9] (o aleatorizado).
     */
    private fun advanceCycle() {
        gamesSinceLastAd = 0
        cycleIndex = (cycleIndex + 1) % AdConfig.AD_CYCLE_INTERVALS.size
        // Seleccionamos intercalando entre 3, 6, 9 con variación aleatoria si se desea
        val nextInOrder = AdConfig.AD_CYCLE_INTERVALS[cycleIndex]
        val randomized = AdConfig.AD_CYCLE_INTERVALS[Random.nextInt(AdConfig.AD_CYCLE_INTERVALS.size)]
        // Alternamos entre el orden del ciclo y variabilidad aleatoria
        currentThreshold = if (Random.nextBoolean()) nextInOrder else randomized
        Log.d(TAG, "Nuevo umbral de partidas para el próximo anuncio: $currentThreshold")
    }

    /**
     * Muestra anuncio bonificado para revivir al jugador o continuar su racha.
     */
    fun showRewardedAd(
        activity: Activity?,
        onRewardEarned: () -> Unit,
        onAdClosed: () -> Unit
    ) {
        val ad = rewardedAd
        if (ad != null && activity != null && isNetworkAvailable()) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    _isRewardedAdReady.value = false
                    loadRewardedAd()
                    onAdClosed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    rewardedAd = null
                    _isRewardedAdReady.value = false
                    loadRewardedAd()
                    onAdClosed()
                }
            }
            ad.show(activity) { rewardItem ->
                Log.d(TAG, "Recompensa otorgada al jugador: ${rewardItem.amount} ${rewardItem.type}")
                onRewardEarned()
            }
        } else {
            // Si está offline o no cargó, notificamos inmediatamente
            onAdClosed()
        }
    }
}

/**
 * Contenedor de Banner superior estilo "Dynamic Island" / cápsula estética.
 *
 * Cumplimiento estricto de Políticas de Google AdMob & Google Play:
 * - Área segura (Safe Area): Ubicado con margen superior basado en insets del sistema (notch / barra de estado).
 * - Sin recortes ni enmascaramiento: NO aplica overflow hidden ni clips redondeados sobre el AdView;
 *   la etiqueta AdChoices y los botones reglamentarios permanecen 100% íntegros y visibles.
 * - Dimensiones estándar: 320dp de ancho x 50dp de alto (estándar BANNER) con espaciado rectangular interno.
 * - Prevención de clics accidentales: Margen transparente de separación antes de los elementos del juego.
 */
@Composable
fun DynamicIslandBanner(
    modifier: Modifier = Modifier,
    adUnitId: String = AdConfig.BANNER_AD_ID,
    advertisementLabel: String = "PUBLICIDAD"
) {
    var isAdLoaded by remember { mutableStateOf(false) }
    var hasError by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        contentAlignment = Alignment.Center
    ) {
        // Cápsula estética de fondo (el marco tiene bordes redondeados, pero el anuncio interno NO se recorta)
        Box(
            modifier = Modifier
                .widthIn(min = 344.dp)
                .background(
                    color = Color(0x3D0F273E),
                    shape = RoundedCornerShape(16.dp)
                )
                .border(
                    width = 1.dp,
                    color = Color(0x33FFFFFF),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(horizontal = 12.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.wrapContentHeight()
            ) {
                // Etiqueta legal requerida por Google AdMob (clara, separada e internacionalizada)
                Text(
                    text = advertisementLabel,
                    color = Color(0x88FFFFFF),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    modifier = Modifier.padding(bottom = 3.dp)
                )

                // Contenedor rectangular intacto para AdView (sin clip, sin overflow hidden)
                Box(
                    modifier = Modifier.size(width = 320.dp, height = 50.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AndroidView(
                        factory = { ctx ->
                            AdView(ctx).apply {
                                setAdSize(AdSize.BANNER)
                                this.adUnitId = adUnitId
                                adListener = object : AdListener() {
                                    override fun onAdLoaded() {
                                        isAdLoaded = true
                                        hasError = false
                                    }

                                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                                        isAdLoaded = false
                                        hasError = true
                                    }
                                }
                                loadAd(AdRequest.Builder().build())
                            }
                        },
                        modifier = Modifier.size(width = 320.dp, height = 50.dp)
                    )
                }
            }
        }
    }
}
